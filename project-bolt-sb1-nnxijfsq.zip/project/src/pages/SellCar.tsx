import React from 'react';
import { Car } from 'lucide-react';
import { CarForm } from '../components/forms/CarForm';

export const SellCar = () => {
  return (
    <div className="min-h-screen bg-gray-100 py-8">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center space-x-2 mb-6">
            <Car className="h-6 w-6 text-blue-600" />
            <h1 className="text-2xl font-bold text-gray-900">Sell Your Car</h1>
          </div>
          <CarForm />
        </div>
      </div>
    </div>
  );
};