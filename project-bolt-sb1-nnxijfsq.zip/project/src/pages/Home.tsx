import React from 'react';
import { CarCard } from '../components/CarCard';
import { Select } from '../components/ui/Select';
import { useCars } from '../hooks/useCars';

const sortOptions = [
  { value: 'latest', label: 'Sort by: Latest' },
  { value: 'price-low', label: 'Price: Low to High' },
  { value: 'price-high', label: 'Price: High to Low' },
  { value: 'mileage', label: 'Mileage: Low to High' }
];

export const Home = () => {
  const { cars, sortBy, setSortBy } = useCars();

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold text-gray-900">Featured Cars</h1>
          <div className="flex space-x-4">
            <Select
              label=""
              options={sortOptions}
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="w-48"
            />
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {cars.map((car) => (
            <CarCard key={car.id} car={car} />
          ))}
        </div>
      </div>
    </div>
  );
};