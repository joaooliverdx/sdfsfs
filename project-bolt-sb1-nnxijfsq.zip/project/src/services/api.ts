import { Car } from '../types/car';

// Simulated API service
export const api = {
  async getCars(): Promise<Car[]> {
    // In a real app, this would be an API call
    return Promise.resolve([
      {
        id: '1',
        make: 'Toyota',
        model: 'Camry',
        year: 2020,
        price: 25000,
        mileage: 35000,
        description: 'Well-maintained Toyota Camry with excellent fuel efficiency',
        imageUrl: 'https://images.unsplash.com/photo-1621007947382-bb3c3994e3fb',
        seller: {
          name: 'John Doe',
          email: 'john@example.com',
          phone: '(555) 123-4567'
        },
        features: ['Bluetooth', 'Backup Camera', 'Keyless Entry'],
        condition: 'Used',
        location: 'Los Angeles, CA',
        createdAt: new Date()
      },
      {
        id: '2',
        make: 'Honda',
        model: 'CR-V',
        year: 2021,
        price: 32000,
        mileage: 15000,
        description: 'Like-new Honda CR-V with all premium features',
        imageUrl: 'https://images.unsplash.com/photo-1568844293986-8d0400bd4745',
        seller: {
          name: 'Jane Smith',
          email: 'jane@example.com',
          phone: '(555) 987-6543'
        },
        features: ['Navigation', 'Leather Seats', 'Sunroof'],
        condition: 'Certified Pre-Owned',
        location: 'San Francisco, CA',
        createdAt: new Date()
      }
    ]);
  },

  async createCar(car: Omit<Car, 'id' | 'createdAt'>): Promise<Car> {
    // In a real app, this would be an API call
    return Promise.resolve({
      ...car,
      id: Math.random().toString(36).substr(2, 9),
      createdAt: new Date()
    });
  }
};