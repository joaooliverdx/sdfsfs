export interface Car {
  id: string;
  make: string;
  model: string;
  year: number;
  price: number;
  mileage: number;
  description: string;
  imageUrl: string;
  seller: {
    name: string;
    email: string;
    phone: string;
  };
  features: string[];
  condition: 'New' | 'Used' | 'Certified Pre-Owned';
  location: string;
  createdAt: Date;
}