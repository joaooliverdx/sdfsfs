import React from 'react';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { Button } from '../ui/Button';
import { Upload } from 'lucide-react';
import { useCarForm } from '../../hooks/useCarForm';

export const CarForm = () => {
  const { formData, handleChange, handleSubmit } = useCarForm();

  const conditionOptions = [
    { value: 'New', label: 'New' },
    { value: 'Used', label: 'Used' },
    { value: 'Certified Pre-Owned', label: 'Certified Pre-Owned' }
  ];

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Input
          label="Make"
          id="make"
          value={formData.make}
          onChange={handleChange}
          name="make"
        />
        <Input
          label="Model"
          id="model"
          value={formData.model}
          onChange={handleChange}
          name="model"
        />
        <Input
          label="Year"
          id="year"
          type="number"
          value={formData.year}
          onChange={handleChange}
          name="year"
        />
        <Input
          label="Price ($)"
          id="price"
          type="number"
          value={formData.price}
          onChange={handleChange}
          name="price"
        />
      </div>

      <Input
        label="Mileage"
        id="mileage"
        type="number"
        value={formData.mileage}
        onChange={handleChange}
        name="mileage"
      />

      <div>
        <label className="block text-sm font-medium text-gray-700">Description</label>
        <textarea
          rows={4}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          value={formData.description}
          onChange={handleChange}
          name="description"
        />
      </div>

      <Select
        label="Condition"
        id="condition"
        options={conditionOptions}
        value={formData.condition}
        onChange={handleChange}
        name="condition"
      />

      <Input
        label="Location"
        id="location"
        value={formData.location}
        onChange={handleChange}
        name="location"
      />

      <div className="border-2 border-dashed border-gray-300 rounded-lg p-6">
        <div className="flex flex-col items-center">
          <Upload className="h-12 w-12 text-gray-400" />
          <p className="mt-1 text-sm text-gray-600">
            Drag and drop your car images here, or click to select files
          </p>
        </div>
      </div>

      <Button type="submit" fullWidth>
        List Your Car
      </Button>
    </form>
  );
};