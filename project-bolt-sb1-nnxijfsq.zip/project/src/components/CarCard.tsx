import React from 'react';
import { Car } from '../types/car';
import { MapPin, Calendar, Gauge } from 'lucide-react';

interface CarCardProps {
  car: Car;
}

export const CarCard: React.FC<CarCardProps> = ({ car }) => {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
      <img
        src={car.imageUrl}
        alt={`${car.year} ${car.make} ${car.model}`}
        className="w-full h-48 object-cover"
      />
      <div className="p-4">
        <div className="flex justify-between items-start">
          <h3 className="text-lg font-semibold">
            {car.year} {car.make} {car.model}
          </h3>
          <span className="text-lg font-bold text-blue-600">
            ${car.price.toLocaleString()}
          </span>
        </div>
        
        <div className="mt-2 space-y-2">
          <div className="flex items-center text-gray-600">
            <MapPin className="h-4 w-4 mr-2" />
            <span>{car.location}</span>
          </div>
          <div className="flex items-center text-gray-600">
            <Calendar className="h-4 w-4 mr-2" />
            <span>{car.year}</span>
          </div>
          <div className="flex items-center text-gray-600">
            <Gauge className="h-4 w-4 mr-2" />
            <span>{car.mileage.toLocaleString()} miles</span>
          </div>
        </div>
        
        <div className="mt-4">
          <span className="inline-block px-2 py-1 text-sm font-semibold text-blue-600 bg-blue-100 rounded">
            {car.condition}
          </span>
        </div>
      </div>
    </div>
  );
}