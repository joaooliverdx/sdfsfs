import { useState, useEffect } from 'react';
import { Car } from '../types/car';
import { api } from '../services/api';

export const useCars = () => {
  const [cars, setCars] = useState<Car[]>([]);
  const [sortBy, setSortBy] = useState<string>('latest');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchCars = async () => {
      try {
        const data = await api.getCars();
        setCars(data);
      } catch (err) {
        setError('Failed to fetch cars');
      } finally {
        setLoading(false);
      }
    };

    fetchCars();
  }, []);

  const sortedCars = [...cars].sort((a, b) => {
    switch (sortBy) {
      case 'price-low':
        return a.price - b.price;
      case 'price-high':
        return b.price - a.price;
      case 'mileage':
        return a.mileage - b.mileage;
      default:
        return b.createdAt.getTime() - a.createdAt.getTime();
    }
  });

  return {
    cars: sortedCars,
    loading,
    error,
    sortBy,
    setSortBy
  };
};