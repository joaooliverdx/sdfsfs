import { useState, FormEvent, ChangeEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../services/api';

interface CarFormData {
  make: string;
  model: string;
  year: string;
  price: string;
  mileage: string;
  description: string;
  condition: string;
  location: string;
}

export const useCarForm = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [formData, setFormData] = useState<CarFormData>({
    make: '',
    model: '',
    year: '',
    price: '',
    mileage: '',
    description: '',
    condition: 'Used',
    location: ''
  });

  const handleChange = (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      await api.createCar({
        ...formData,
        year: parseInt(formData.year),
        price: parseInt(formData.price),
        mileage: parseInt(formData.mileage),
        imageUrl: 'https://images.unsplash.com/photo-1621007947382-bb3c3994e3fb',
        seller: {
          name: 'Current User',
          email: 'user@example.com',
          phone: '(555) 123-4567'
        },
        features: []
      });
      navigate('/');
    } catch (err) {
      setError('Failed to create listing');
    } finally {
      setLoading(false);
    }
  };

  return {
    formData,
    loading,
    error,
    handleChange,
    handleSubmit
  };
};